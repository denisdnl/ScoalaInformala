function hideLoadingModal() {
  document.getElementById("loadingModal").classList = ["loadingModalHidden"];
}

function showLoadingModal() {
  document.getElementById("loadingModal").classList = ["loadingModalShown"];
}


function login(){
  window.location = "actiune.html";
}